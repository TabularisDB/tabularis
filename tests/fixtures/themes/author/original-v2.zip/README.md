# fixture-theme

Two declarative Tabularis variants. Edit themes/*.json, then run:

```sh
node tools/theme.mjs validate .
node tools/theme.mjs package . --output theme-universal.zip
```

Use Settings → Appearance → Local package to preview/install the ZIP. Installation does not select a variant. No account or network is needed.

## Before publishing

Assign an appropriate license and retain upstream attribution. Importing does not grant redistribution rights. Replace LICENSE.txt. Take screenshots of both variants; host them in your repository and add HTTPS screenshots metadata to .tabularium (not executable/archive payload).

Schemas: https://github.com/TabularisDB/tabularis/tree/main/public/schemas (offline validation is bundled in tools/theme.mjs; no schema URL is fetched).

Set min_runtime_version to the actual first supporting Tabularis release, not an older release with the same development version. No supporting release has been assigned by this scaffold. Match manifest version to the v-prefixed tag. Push a tag to create a draft GitHub release, review its universal ZIP, then publish the release and submit your repository through Tabularium. A GitHub release does not imply registry authorization, moderation approval, theme-kind enablement or successful ingestion.

Full guide: https://github.com/TabularisDB/tabularis/blob/main/packages/create-plugin/THEMES.md
