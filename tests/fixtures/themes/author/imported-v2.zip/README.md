# Imported fixture

Exported from Tabularis. Review attribution and obtain redistribution rights before publication.
